#!/bin/bash

nvidia-smi
nvcc --version
